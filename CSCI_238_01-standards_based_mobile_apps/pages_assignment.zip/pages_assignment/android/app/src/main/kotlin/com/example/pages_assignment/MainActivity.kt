package com.example.pages_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
