<h1>Car Upload Database</h1>

<nav style="position: relative; top: 0px;">
	<a href="index.php">Home</a>
	<a href="page1.php">Show Cars</a>
</nav>