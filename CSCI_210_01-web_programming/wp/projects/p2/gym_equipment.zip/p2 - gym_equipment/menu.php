<div>
	<a href="index.php">Home</a>
	<a href="inventory.php">Inventory</a><br><br>
</div>